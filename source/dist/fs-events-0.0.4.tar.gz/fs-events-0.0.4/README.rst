fs-events
===================================

fs-events is a library for monitoring file system events.
It exposes thest events via generators.


Installation
==================================

pip install fs-events


Usage
==================================

